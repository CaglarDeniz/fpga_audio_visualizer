/*
 * main.h
 *
 *  Created on: Dec 8, 2022
 *      Author: dcaglar2
 */

#ifndef MAIN_H_
#define MAIN_H_

#define ONCHIP_MEMORY_SIZE 41087;





#endif /* MAIN_H_ */
