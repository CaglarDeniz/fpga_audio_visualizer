/*
 * main.c
 *
 *  Created on: Dec 8, 2022
 *      Author: dcaglar2
 */
#include <stdio.h>
#include <stdint.h>

#include "linker.h"

#include "libhelix-mp3/pub/mp3dec.h"

uint8_t * onchip_mem = (uint8_t *)ONCHIP_MEMORY2_0_REGION_BASE;

HMP3Decoder mp3dec;

short outBuf[MAX_NCHAN * MAX_NGRAN * MAX_NSAMP];

int main(){
	int i;
	for(i = 0; i < 8 ; i++){
		printf("The contents of memory at index %x : %x\n", i , onchip_mem[i]);
	}

	mp3dec = MP3InitDecoder();
	uint8_t * readPtr;
	int bytesLeft = 4096;

	int sync_word ;
	sync_word = MP3FindSyncWord(onchip_mem,4096);

	readPtr += sync_word;
	bytesLeft -= sync_word;

	int err;

	err = MP3Decode(mp3dec, &readPtr, &bytesLeft,outBuf,0);

	if(err){
		switch (err) {
					case ERR_MP3_INDATA_UNDERFLOW:
						printf("INDATA UNDERFLOW");
						break;
					case ERR_MP3_MAINDATA_UNDERFLOW:
						/* do nothing - next call to decode will provide more mainData */
						printf("MAINDATA UNDERFLOW");
						break;
					case ERR_MP3_FREE_BITRATE_SYNC:
						printf('FREE BITRATE_SYNC');
						break;
					default:
						printf('DEFAULT ERR');
						break;
					}
	}

//	printf("Index of first sync word is %d",sync_word);
}
